# iteration
Repo for "iteration" keyword for Digital Pedagogy in the Humanities, curated by Annette Vee
Items are gathered here: https://www.dropbox.com/home/IterationPedagogicalMaterials
